# 🧪 Selenium TestNG Automation Framework

A production-ready test automation framework built with **Java**, **Selenium WebDriver**, and **TestNG** — following industry best practices including Page Object Model (POM), parallel execution, data-driven testing, and CI/CD integration.

---

## 📁 Project Structure

```
selenium-testng-framework/
├── src/
│   ├── main/java/com/automation/
│   │   ├── base/
│   │   │   ├── BasePage.java          # Reusable Selenium actions (click, type, wait...)
│   │   │   ├── BaseTest.java          # TestNG setup/teardown + report hooks
│   │   │   └── DriverManager.java     # ThreadLocal WebDriver (parallel-safe)
│   │   ├── config/
│   │   │   └── ConfigReader.java      # Singleton config loader (env-aware)
│   │   ├── pages/
│   │   │   ├── LoginPage.java         # POM: Login page
│   │   │   ├── DashboardPage.java     # POM: Dashboard page
│   │   │   └── FormPage.java          # POM: Form interactions
│   │   └── utils/
│   │       ├── ExtentReportManager.java  # HTML report lifecycle
│   │       ├── ScreenshotUtil.java       # Screenshot capture on failure
│   │       ├── TestDataUtil.java         # JavaFaker random test data
│   │       └── WaitUtil.java             # Custom explicit waits
│   └── test/
│       ├── java/com/automation/
│       │   ├── tests/
│       │   │   ├── LoginTest.java         # Login: positive, negative, data-driven
│       │   │   ├── FormTest.java          # Form: valid, invalid, boundary, security
│       │   │   └── UserWorkflowTest.java  # E2E: full user journeys
│       │   └── listeners/
│       │       ├── TestListener.java      # ITestListener + ISuiteListener
│       │       └── RetryAnalyzer.java     # Auto-retry flaky tests
│       └── resources/
│           ├── testng.xml                 # Suite config (parallel, groups)
│           ├── config.properties          # Default config
│           ├── config-staging.properties  # Staging overrides
│           └── log4j2.xml                 # Logging config
├── .github/workflows/ci.yml              # GitHub Actions pipeline
├── Jenkinsfile                            # Jenkins pipeline
├── pom.xml                                # Maven dependencies
└── README.md
```

---

## ⚙️ Prerequisites

| Tool    | Version   |
|---------|-----------|
| Java    | 11+       |
| Maven   | 3.8+      |
| Chrome  | Latest    |
| Firefox | Latest (optional) |

---

## 🚀 How to Run

### Run all smoke tests (default)
```bash
mvn clean test
```

### Run specific test group
```bash
mvn test -Dgroups=smoke
mvn test -Dgroups=regression
mvn test -Dgroups=e2e
mvn test -Dgroups=security
```

### Run on a different browser
```bash
mvn test -Dbrowser=firefox
mvn test -Dbrowser=edge
```

### Run headless (CI mode)
```bash
mvn test -Dheadless=true
```

### Run against staging environment
```bash
mvn test -Denv=staging
```

### Combine options
```bash
mvn test -Dbrowser=chrome -Dheadless=true -Denv=staging -Dgroups=regression
```

### Run a single test class
```bash
mvn test -Dtest=LoginTest
```

---

## 📊 Reports

After execution, reports are generated in the `reports/` directory:

| Report | Path |
|--------|------|
| **Extent HTML Report** | `reports/TestReport_<timestamp>.html` |
| **TestNG XML Report**  | `target/surefire-reports/testng-results.xml` |
| **Screenshots**        | `reports/screenshots/` |
| **Logs**               | `reports/logs/automation.log` |

Open the HTML report in any browser for a full test execution summary.

---

## 🔑 Key Features

### ✅ Page Object Model (POM)
All pages extend `BasePage` and use `@FindBy` annotations with `PageFactory`. Page actions return page objects for fluent chaining:
```java
new LoginPage(driver).open()
    .enterUsername("tomsmith")
    .enterPassword("SuperSecretPassword!")
    .clickLogin();
```

### ✅ ThreadLocal WebDriver (Parallel Safe)
`DriverManager` stores WebDriver in a `ThreadLocal`, enabling parallel test execution without thread conflicts.

### ✅ Data-Driven Testing
Tests use TestNG `@DataProvider` for table-driven inputs:
```java
@DataProvider(name = "invalidCredentials")
public Object[][] data() {
    return new Object[][] {
        {"wrong_user", "wrong_pass"},
        {"",           ""},
        // ...
    };
}
```

### ✅ Random Test Data
`TestDataUtil` wraps `JavaFaker` for realistic, randomized data:
```java
Map<String, String> user = TestDataUtil.generateUser();
// Returns: firstName, lastName, email, phone, password, city, country
```

### ✅ Auto-Retry Flaky Tests
Attach `RetryAnalyzer` to any test:
```java
@Test(retryAnalyzer = RetryAnalyzer.class)
public void testSomething() { ... }
```

### ✅ Environment-Aware Config
Switch environments with a single flag — no code changes needed:
```bash
mvn test -Denv=staging
```

### ✅ CI/CD Ready
- **Jenkins**: Full `Jenkinsfile` with parameterized builds, reports, and email notifications
- **GitHub Actions**: `.github/workflows/ci.yml` with nightly schedule and artifact upload

---

## 🧩 Adding a New Page

1. Create `src/main/java/com/automation/pages/MyPage.java`
2. Extend `BasePage`
3. Add `@FindBy` locators
4. Write fluent action methods
5. Return `this` or next page object

```java
public class MyPage extends BasePage {
    @FindBy(id = "submit-btn")
    private WebElement submitButton;

    public MyPage(WebDriver driver) { super(driver); }

    public MyPage clickSubmit() {
        click(submitButton);
        return this;
    }
}
```

---

## 🧩 Adding a New Test

```java
public class MyTest extends BaseTest {

    @Test(groups = {"smoke"}, description = "My test description")
    public void testSomething() {
        logStep("Step 1: Navigate");
        new MyPage(driver).open().clickSubmit();
        Assert.assertTrue(condition, "Expected outcome");
        logPass("Test verified");
    }
}
```

Then add the class to `testng.xml`.

---

## 🏷️ Test Groups

| Group        | Purpose                                  |
|--------------|------------------------------------------|
| `smoke`      | Core sanity checks — fast, critical only |
| `regression` | Full functional coverage                 |
| `e2e`        | End-to-end user journey flows            |
| `security`   | Input validation, XSS, SQL injection     |

---

## 🛠️ Tech Stack

| Component         | Library/Tool               |
|-------------------|----------------------------|
| Browser Automation | Selenium WebDriver 4.x    |
| Test Framework     | TestNG 7.x                |
| Driver Management  | WebDriverManager 5.x      |
| Reporting          | ExtentReports 5.x         |
| Logging            | Log4j2                    |
| Test Data          | JavaFaker                 |
| Assertions         | TestNG Assert + AssertJ   |
| Build Tool         | Maven                     |
| CI/CD              | Jenkins + GitHub Actions  |

---

## 👥 Author

Built with ❤️ by the QA Automation Team
