package com.automation.listeners;

import com.automation.utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.*;

/**
 * TestNG ITestListener + ISuiteListener for cross-cutting concerns:
 * - Logs test lifecycle events
 * - Logs retry info
 * - Hooks into ExtentReports
 */
public class TestListener implements ITestListener, ISuiteListener {

    private static final Logger log = LogManager.getLogger(TestListener.class);

    // ─── ISuiteListener ──────────────────────────────────────────────────────────

    @Override
    public void onStart(ISuite suite) {
        log.info("========================================");
        log.info("  Suite: {}  started", suite.getName());
        log.info("========================================");
    }

    @Override
    public void onFinish(ISuite suite) {
        log.info("========================================");
        log.info("  Suite: {}  finished", suite.getName());
        log.info("========================================");
    }

    // ─── ITestListener ───────────────────────────────────────────────────────────

    @Override
    public void onTestStart(ITestResult result) {
        log.info("▶ Starting: [{}] {}", result.getTestClass().getName(), result.getName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        log.info("✅ PASSED: {}", result.getName());
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) test.log(Status.PASS, "Test Passed ✔");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        log.error("❌ FAILED: {} → {}", result.getName(), result.getThrowable().getMessage());
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) {
            test.log(Status.FAIL, "Test Failed ✘");
            test.log(Status.FAIL, result.getThrowable());
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        log.warn("⏭ SKIPPED: {}", result.getName());
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) test.log(Status.SKIP, "Test Skipped ⏭");
    }

    @Override
    public void onTestFailedWithTimeout(ITestResult result) {
        log.error("⏰ TIMED OUT: {}", result.getName());
        onTestFailure(result);
    }

    @Override
    public void onFinish(ITestContext context) {
        int total   = context.getAllTestMethods().length;
        int passed  = context.getPassedTests().size();
        int failed  = context.getFailedTests().size();
        int skipped = context.getSkippedTests().size();

        log.info("────────────────────────────────────────");
        log.info("  Results | Total: {} | ✅ {}, ❌ {}, ⏭ {}", total, passed, failed, skipped);
        log.info("────────────────────────────────────────");
    }
}
