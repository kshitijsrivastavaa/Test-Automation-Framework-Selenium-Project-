package com.automation.tests;

import com.automation.base.BaseTest;
import com.automation.pages.DashboardPage;
import com.automation.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Test class for Login functionality.
 *
 * Covers:
 *   - Successful login with valid credentials
 *   - Failed login with invalid credentials
 *   - Empty field validations
 *   - Logout flow
 *   - Data-driven login tests
 */
public class LoginTest extends BaseTest {

    // ─── Positive Tests ──────────────────────────────────────────────────────────

    @Test(
        groups    = {"smoke", "regression"},
        priority  = 1,
        description = "Verify that a user can log in with valid credentials"
    )
    public void testSuccessfulLogin() {
        logStep("Opening login page");
        LoginPage loginPage = new LoginPage(driver).open();

        logStep("Entering valid credentials");
        DashboardPage dashboard = loginPage.loginAs(
                config.getUsername(),
                config.getPassword()
        );

        logStep("Verifying successful login");
        Assert.assertTrue(dashboard.isLoggedIn(), "User should be logged in");
        Assert.assertTrue(dashboard.isDashboardUrlCorrect(), "URL should contain /secure");

        logPass("Login test passed");
    }

    @Test(
        groups    = {"regression"},
        priority  = 2,
        description = "Verify login banner message appears after successful login"
    )
    public void testLoginSuccessBannerDisplayed() {
        LoginPage loginPage = new LoginPage(driver).open();
        DashboardPage dashboard = loginPage.loginAs(
                config.getUsername(),
                config.getPassword()
        );

        Assert.assertTrue(dashboard.isLoginBannerDisplayed(), "Success banner should appear");
        Assert.assertTrue(
            dashboard.getLoginBannerText().toLowerCase().contains("logged in"),
            "Banner should confirm login"
        );
    }

    // ─── Negative Tests ──────────────────────────────────────────────────────────

    @Test(
        groups    = {"smoke", "regression"},
        priority  = 3,
        description = "Verify error message for invalid credentials"
    )
    public void testLoginWithInvalidCredentials() {
        logStep("Opening login page");
        LoginPage loginPage = new LoginPage(driver).open();

        logStep("Entering invalid credentials");
        loginPage.loginWithInvalidCreds("invalid_user", "wrong_password");

        logStep("Verifying error message");
        Assert.assertTrue(loginPage.isErrorMessageDisplayed(), "Error message should appear");
        Assert.assertTrue(
            loginPage.getErrorMessage().toLowerCase().contains("invalid"),
            "Error message should mention 'invalid'"
        );
        Assert.assertTrue(loginPage.isOnLoginPage(), "User should remain on login page");

        logPass("Invalid credentials rejection verified");
    }

    @Test(
        groups    = {"regression"},
        priority  = 4,
        description = "Verify empty username shows error"
    )
    public void testLoginWithEmptyUsername() {
        LoginPage loginPage = new LoginPage(driver).open();
        loginPage.loginWithInvalidCreds("", config.getPassword());

        Assert.assertTrue(loginPage.isErrorMessageDisplayed(), "Error should appear for empty username");
        Assert.assertTrue(loginPage.isOnLoginPage(), "Should stay on login page");
    }

    @Test(
        groups    = {"regression"},
        priority  = 5,
        description = "Verify empty password shows error"
    )
    public void testLoginWithEmptyPassword() {
        LoginPage loginPage = new LoginPage(driver).open();
        loginPage.loginWithInvalidCreds(config.getUsername(), "");

        Assert.assertTrue(loginPage.isErrorMessageDisplayed(), "Error should appear for empty password");
    }

    @Test(
        groups    = {"regression"},
        priority  = 6,
        description = "Verify user can logout successfully"
    )
    public void testLogout() {
        logStep("Login first");
        DashboardPage dashboard = new LoginPage(driver).open()
                .loginAs(config.getUsername(), config.getPassword());
        Assert.assertTrue(dashboard.isLoggedIn());

        logStep("Logging out");
        LoginPage loginPage = dashboard.logout();

        logStep("Verify redirected to login");
        Assert.assertTrue(loginPage.isOnLoginPage(), "Should be redirected to login page after logout");
    }

    // ─── Data-Driven Tests ───────────────────────────────────────────────────────

    @DataProvider(name = "invalidCredentials")
    public Object[][] invalidCredentialsProvider() {
        return new Object[][] {
            {"wrong_user",       "wrong_pass",          "invalid username"},
            {"tomsmith",         "wrongpassword",        "wrong password"},
            {"",                 "",                     "both empty"},
            {"<script>",         "xss_attempt",          "XSS in username"},
            {"' OR '1'='1",      "sql_inject",           "SQL injection"},
            {"admin",            "admin",                "common default creds"},
            {"a".repeat(1000),   "b",                    "very long username"},
        };
    }

    @Test(
        dataProvider = "invalidCredentials",
        groups       = {"regression", "security"},
        description  = "Data-driven: various invalid credential combinations should fail"
    )
    public void testVariousInvalidCredentials(String username, String password, String scenario) {
        logStep("Testing scenario: " + scenario);
        LoginPage loginPage = new LoginPage(driver).open();
        loginPage.loginWithInvalidCreds(username, password);

        Assert.assertTrue(
            loginPage.isErrorMessageDisplayed() || loginPage.isOnLoginPage(),
            "Should fail for: " + scenario
        );
    }
}
