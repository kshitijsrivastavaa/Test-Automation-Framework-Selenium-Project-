package com.automation.tests;

import com.automation.base.BaseTest;
import com.automation.pages.DashboardPage;
import com.automation.pages.FormPage;
import com.automation.pages.LoginPage;
import com.automation.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * End-to-end user workflow tests.
 *
 * Covers complete user journeys:
 *   - Login → View Dashboard → Logout
 *   - Login → Fill Form → Submit → Verify → Logout
 *   - Session management
 *   - Navigation between pages
 */
public class UserWorkflowTest extends BaseTest {

    @Test(
        groups    = {"smoke", "e2e"},
        priority  = 1,
        description = "E2E: User logs in, verifies dashboard, and logs out"
    )
    public void testLoginDashboardLogoutFlow() {
        logStep("Step 1: Navigate to login");
        LoginPage loginPage = new LoginPage(driver).open();
        Assert.assertTrue(loginPage.isOnLoginPage(), "Should be on login page");

        logStep("Step 2: Login with valid credentials");
        DashboardPage dashboard = loginPage.loginAs(
                config.getUsername(), config.getPassword()
        );
        Assert.assertTrue(dashboard.isLoggedIn(), "Should be logged in");
        Assert.assertTrue(dashboard.isDashboardUrlCorrect(), "URL should be secure dashboard");

        logStep("Step 3: Verify dashboard heading");
        String heading = dashboard.getPageHeading();
        Assert.assertNotNull(heading, "Dashboard heading should not be null");
        Assert.assertFalse(heading.isEmpty(), "Dashboard heading should not be empty");

        logStep("Step 4: Logout");
        loginPage = dashboard.logout();
        Assert.assertTrue(loginPage.isOnLoginPage(), "Should be back on login page");

        logPass("Complete login-dashboard-logout flow verified");
    }

    @Test(
        groups    = {"e2e", "regression"},
        priority  = 2,
        description = "E2E: Login → navigate to form → fill with random data → submit"
    )
    public void testLoginThenFormSubmissionWorkflow() {
        logStep("Step 1: Login");
        DashboardPage dashboard = new LoginPage(driver).open()
                .loginAs(config.getUsername(), config.getPassword());
        Assert.assertTrue(dashboard.isLoggedIn());

        logStep("Step 2: Navigate to form page");
        FormPage formPage = new FormPage(driver).open();

        logStep("Step 3: Fill form with random data");
        Map<String, String> data = TestDataUtil.generateFormData();
        formPage.fillAndSubmit(
            data.get("firstName"),
            data.get("lastName"),
            data.get("email"),
            data.get("phone"),
            "United States",
            "male",
            data.get("comments")
        );

        logStep("Step 4: Verify form was submitted");
        Assert.assertTrue(formPage.isSuccessMessageDisplayed(),
                "Form success message should appear");

        logPass("Login → Form submission workflow verified");
    }

    @Test(
        groups    = {"e2e", "regression"},
        priority  = 3,
        description = "E2E: Verify session expires and login required again after logout"
    )
    public void testSessionManagement() {
        logStep("Login");
        DashboardPage dashboard = new LoginPage(driver).open()
                .loginAs(config.getUsername(), config.getPassword());
        Assert.assertTrue(dashboard.isLoggedIn());

        logStep("Logout");
        LoginPage loginPage = dashboard.logout();

        logStep("Try to access secure page directly after logout");
        driver.get(config.getBaseUrl() + "/secure");

        logStep("Verify user is redirected to login page");
        Assert.assertTrue(
            driver.getCurrentUrl().contains("/login") || loginPage.isOnLoginPage(),
            "Unauthenticated access should redirect to login"
        );

        logPass("Session management test passed");
    }

    @Test(
        groups    = {"regression"},
        priority  = 4,
        description = "Verify browser back button does not re-enter secure area after logout"
    )
    public void testBrowserBackAfterLogout() {
        logStep("Login and then logout");
        DashboardPage dashboard = new LoginPage(driver).open()
                .loginAs(config.getUsername(), config.getPassword());
        dashboard.logout();

        logStep("Navigate back using browser history");
        driver.navigate().back();

        logStep("Verify still on login or redirected");
        boolean onLogin = driver.getCurrentUrl().contains("/login");
        boolean onSecure = driver.getCurrentUrl().contains("/secure");

        // Either it's on login OR if on secure, user is NOT logged in
        if (onSecure) {
            // Some apps allow back but the session is invalid
            logStep("On secure URL - checking if truly logged in");
            Assert.assertFalse(
                new DashboardPage(driver).isLoggedIn(),
                "After logout, back button should not restore session"
            );
        } else {
            Assert.assertTrue(onLogin, "Should be on login page after back");
        }

        logPass("Back button post-logout test verified");
    }

    @Test(
        groups    = {"regression"},
        priority  = 5,
        description = "Verify page title is correct on login page"
    )
    public void testPageTitles() {
        logStep("Check login page title");
        new LoginPage(driver).open();
        String loginTitle = driver.getTitle();
        Assert.assertNotNull(loginTitle);
        Assert.assertFalse(loginTitle.isEmpty(), "Login page should have a title");
        logStep("Login page title: " + loginTitle);

        logStep("Check dashboard page title");
        DashboardPage dashboard = new LoginPage(driver).open()
                .loginAs(config.getUsername(), config.getPassword());
        String dashboardTitle = driver.getTitle();
        Assert.assertNotNull(dashboardTitle);
        Assert.assertFalse(dashboardTitle.isEmpty(), "Dashboard should have a title");
        logStep("Dashboard title: " + dashboardTitle);

        logPass("Page title checks passed");
    }
}
