package com.automation.tests;

import com.automation.base.BaseTest;
import com.automation.pages.FormPage;
import com.automation.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * Test class for Form functionality.
 *
 * Covers:
 *   - Valid form submission
 *   - Required field validations
 *   - Boundary value tests
 *   - Dynamic data-driven submission
 *   - XSS / SQL injection input handling
 */
public class FormTest extends BaseTest {

    private FormPage formPage;

    @BeforeMethod(alwaysRun = true)
    public void openFormPage() {
        formPage = new FormPage(driver).open();
    }

    // ─── Positive Tests ──────────────────────────────────────────────────────────

    @Test(
        groups    = {"smoke", "regression"},
        priority  = 1,
        description = "Verify form submits successfully with all valid data"
    )
    public void testValidFormSubmission() {
        Map<String, String> data = TestDataUtil.generateFormData();

        logStep("Filling form with generated data: " + data.get("email"));
        formPage.fillAndSubmit(
            data.get("firstName"),
            data.get("lastName"),
            data.get("email"),
            data.get("phone"),
            "United States",
            "male",
            data.get("comments")
        );

        logStep("Verifying success message");
        Assert.assertTrue(formPage.isSuccessMessageDisplayed(),
                "Success message should appear after valid submission");

        logPass("Form submission test passed");
    }

    @Test(
        groups    = {"regression"},
        priority  = 2,
        description = "Verify required field error when first name is empty"
    )
    public void testEmptyFirstName() {
        logStep("Submitting without first name");
        formPage.enterLastName("Doe")
                .enterEmail(TestDataUtil.randomEmail())
                .submit();

        Assert.assertTrue(formPage.isErrorMessageDisplayed() || !formPage.isSuccessMessageDisplayed(),
                "Error should appear when first name is empty");
    }

    @Test(
        groups    = {"regression"},
        priority  = 3,
        description = "Verify invalid email format is rejected"
    )
    public void testInvalidEmailFormat() {
        logStep("Entering invalid email");
        formPage.enterFirstName("John")
                .enterLastName("Doe")
                .enterEmail("not-an-email")
                .submit();

        Assert.assertFalse(formPage.isSuccessMessageDisplayed(),
                "Form should not succeed with invalid email");
    }

    @Test(
        groups    = {"regression"},
        priority  = 4,
        description = "Verify country dropdown selection works"
    )
    public void testCountryDropdownSelection() {
        logStep("Selecting country from dropdown");
        formPage.enterFirstName(TestDataUtil.randomFirstName())
                .enterEmail(TestDataUtil.randomEmail())
                .selectCountry("Canada")
                .submit();

        // Presence of this action not throwing = dropdown worked
        Assert.assertNotNull(driver.getCurrentUrl());
    }

    @Test(
        groups    = {"regression"},
        priority  = 5,
        description = "Verify terms checkbox must be checked"
    )
    public void testTermsCheckboxRequired() {
        logStep("Filling form without accepting terms");
        formPage.enterFirstName(TestDataUtil.randomFirstName())
                .enterLastName(TestDataUtil.randomLastName())
                .enterEmail(TestDataUtil.randomEmail())
                .submit(); // No acceptTerms()

        Assert.assertFalse(formPage.isSuccessMessageDisplayed(),
                "Form should not submit without accepting terms");
    }

    // ─── Boundary Tests ──────────────────────────────────────────────────────────

    @Test(
        groups    = {"regression"},
        priority  = 6,
        description = "Verify maximum length input in first name field"
    )
    public void testMaxLengthFirstName() {
        logStep("Entering 255-character first name");
        String longName = TestDataUtil.longString(255);
        formPage.enterFirstName(longName);

        // Verify page doesn't crash
        Assert.assertNotNull(driver.getCurrentUrl(), "Page should remain stable with long input");
    }

    // ─── Security Tests ──────────────────────────────────────────────────────────

    @Test(
        groups    = {"regression", "security"},
        priority  = 7,
        description = "Verify XSS payload in form field is handled safely"
    )
    public void testXssInFirstName() {
        String xss = TestDataUtil.xssPayload();
        logStep("Entering XSS payload: " + xss);
        formPage.enterFirstName(xss)
                .enterEmail(TestDataUtil.randomEmail())
                .acceptTerms()
                .submit();

        // Page should not execute script
        String title = driver.getTitle();
        Assert.assertFalse(title.isEmpty(), "Page should remain stable after XSS input");
    }

    @Test(
        groups    = {"regression", "security"},
        priority  = 8,
        description = "Verify SQL injection in email field is handled safely"
    )
    public void testSqlInjectionInEmail() {
        logStep("Entering SQL injection payload");
        formPage.enterFirstName("Safe Name")
                .enterEmail(TestDataUtil.sqlInjectionPayload())
                .submit();

        Assert.assertFalse(formPage.isSuccessMessageDisplayed(),
                "SQL injection in email should not succeed");
    }

    // ─── Data-Driven Tests ───────────────────────────────────────────────────────

    @DataProvider(name = "validFormData")
    public Object[][] validFormDataProvider() {
        return new Object[][] {
            {"Alice",  "Smith",  TestDataUtil.randomEmail(), "1234567890", "United States", "female"},
            {"Bob",    "Jones",  TestDataUtil.randomEmail(), "9876543210", "Canada",        "male"},
            {"Carlos", "García", TestDataUtil.randomEmail(), "5555555555", "Mexico",        "male"},
        };
    }

    @Test(
        dataProvider = "validFormData",
        groups       = {"regression"},
        description  = "Data-driven: submit form with different valid datasets"
    )
    public void testFormWithMultipleValidDatasets(
            String firstName, String lastName,
            String email, String phone,
            String country, String gender) {

        logStep(String.format("Submitting form for: %s %s (%s)", firstName, lastName, email));
        formPage.fillAndSubmit(firstName, lastName, email, phone, country, gender, "Automated test entry");

        Assert.assertTrue(formPage.isSuccessMessageDisplayed(),
                "Form should succeed for: " + firstName + " " + lastName);
    }
}
