package com.automation.utils;

import com.github.javafaker.Faker;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Generates randomized test data using JavaFaker.
 * Use this in tests to avoid hardcoded data.
 */
public class TestDataUtil {

    private static final Faker faker = new Faker();
    private static final Random random = new Random();

    private TestDataUtil() {}

    // ─── User Data ───────────────────────────────────────────────────────────────

    public static String randomFirstName()  { return faker.name().firstName(); }
    public static String randomLastName()   { return faker.name().lastName(); }
    public static String randomFullName()   { return faker.name().fullName(); }
    public static String randomEmail()      { return faker.internet().emailAddress(); }
    public static String randomPhone()      { return faker.phoneNumber().cellPhone(); }
    public static String randomPassword()   {
        return faker.internet().password(8, 16, true, true, true);
    }

    // ─── Address ─────────────────────────────────────────────────────────────────

    public static String randomCity()       { return faker.address().city(); }
    public static String randomStreet()     { return faker.address().streetAddress(); }
    public static String randomZipCode()    { return faker.address().zipCode(); }
    public static String randomCountry()    { return faker.address().country(); }

    // ─── Text ────────────────────────────────────────────────────────────────────

    public static String randomSentence()   { return faker.lorem().sentence(); }
    public static String randomParagraph()  { return faker.lorem().paragraph(); }
    public static String randomWord()       { return faker.lorem().word(); }

    // ─── Numbers ─────────────────────────────────────────────────────────────────

    public static int randomInt(int min, int max) { return random.nextInt(max - min + 1) + min; }
    public static long randomLong()               { return faker.number().randomNumber(); }

    // ─── Compound builders ───────────────────────────────────────────────────────

    public static Map<String, String> generateUser() {
        Map<String, String> user = new HashMap<>();
        user.put("firstName", randomFirstName());
        user.put("lastName",  randomLastName());
        user.put("email",     randomEmail());
        user.put("phone",     randomPhone());
        user.put("password",  randomPassword());
        user.put("city",      randomCity());
        user.put("country",   randomCountry());
        return user;
    }

    public static Map<String, String> generateFormData() {
        Map<String, String> data = new HashMap<>();
        data.put("firstName", randomFirstName());
        data.put("lastName",  randomLastName());
        data.put("email",     randomEmail());
        data.put("phone",     randomPhone());
        data.put("comments",  randomParagraph());
        return data;
    }

    // ─── Edge-case / boundary data ───────────────────────────────────────────────

    public static String longString(int length) {
        return "A".repeat(length);
    }

    public static String specialCharacters() {
        return "!@#$%^&*()<>?/\\|{}~`';:";
    }

    public static String sqlInjectionPayload() {
        return "' OR '1'='1'; DROP TABLE users; --";
    }

    public static String xssPayload() {
        return "<script>alert('XSS')</script>";
    }
}
