package com.automation.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Utility to capture and save screenshots.
 */
public class ScreenshotUtil {

    private static final Logger log = LogManager.getLogger(ScreenshotUtil.class);
    private static final String SCREENSHOT_DIR = "reports/screenshots";

    private ScreenshotUtil() {}

    /**
     * Captures a screenshot and saves it to reports/screenshots/.
     * @param driver  Active WebDriver instance
     * @param name    Descriptive name for the screenshot
     * @return        Absolute path to saved screenshot, or null on failure
     */
    public static String capture(WebDriver driver, String name) {
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String safeName = name.replaceAll("[^a-zA-Z0-9_-]", "_");
            String fileName = safeName + "_" + timestamp + ".png";

            Path destDir = Paths.get(SCREENSHOT_DIR);
            Files.createDirectories(destDir);

            Path destPath = destDir.resolve(fileName);
            Files.copy(srcFile.toPath(), destPath);

            String absolutePath = destPath.toAbsolutePath().toString();
            log.info("Screenshot saved: {}", absolutePath);
            return absolutePath;

        } catch (IOException e) {
            log.error("Failed to save screenshot: {}", e.getMessage());
            return null;
        } catch (Exception e) {
            log.error("Unexpected error capturing screenshot: {}", e.getMessage());
            return null;
        }
    }
}
