package com.automation.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Manages ExtentReports lifecycle and per-thread test nodes.
 */
public class ExtentReportManager {

    private static final Logger log = LogManager.getLogger(ExtentReportManager.class);
    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> testThread = new ThreadLocal<>();

    private ExtentReportManager() {}

    public static void initReports() {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String reportPath = "reports/TestReport_" + timestamp + ".html";

        ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
        spark.config().setTheme(Theme.DARK);
        spark.config().setDocumentTitle("Automation Test Report");
        spark.config().setReportName("Selenium + TestNG Framework");
        spark.config().setTimeStampFormat("MMM d, yyyy HH:mm:ss");
        spark.config().setCss(".badge-primary { background-color: #6366f1; }");

        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Framework",  "Selenium + TestNG + Java");
        extent.setSystemInfo("Author",     System.getProperty("user.name", "QA Team"));
        extent.setSystemInfo("Environment", System.getProperty("env", "dev").toUpperCase());
        extent.setSystemInfo("Browser",    System.getProperty("browser", "chrome"));
        extent.setSystemInfo("OS",         System.getProperty("os.name"));
        extent.setSystemInfo("Java",       System.getProperty("java.version"));

        log.info("ExtentReports initialized → {}", reportPath);
    }

    public static ExtentTest createTest(String testName, String description) {
        ExtentTest test = description.isEmpty()
                ? extent.createTest(testName)
                : extent.createTest(testName, description);
        testThread.set(test);
        return test;
    }

    public static void setTest(ExtentTest test) {
        testThread.set(test);
    }

    public static ExtentTest getTest() {
        return testThread.get();
    }

    public static void flushReports() {
        if (extent != null) {
            extent.flush();
            log.info("ExtentReports flushed.");
        }
    }

    public static void removeTest() {
        testThread.remove();
    }
}
