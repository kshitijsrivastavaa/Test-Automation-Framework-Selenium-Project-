package com.automation.pages;

import com.automation.base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for the Login page.
 * Targets: https://the-internet.herokuapp.com/login (or configurable base URL)
 */
public class LoginPage extends BasePage {

    // ─── Locators (via @FindBy + PageFactory) ────────────────────────────────────

    @FindBy(id = "username")
    private WebElement usernameInput;

    @FindBy(id = "password")
    private WebElement passwordInput;

    @FindBy(css = "button[type='submit']")
    private WebElement loginButton;

    @FindBy(css = ".flash.success")
    private WebElement successMessage;

    @FindBy(css = ".flash.error")
    private WebElement errorMessage;

    @FindBy(linkText = "Forgot Password")
    private WebElement forgotPasswordLink;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    // ─── Page Actions ────────────────────────────────────────────────────────────

    public LoginPage open() {
        navigateTo(config.getBaseUrl() + "/login");
        log.info("Opened Login page");
        return this;
    }

    public LoginPage enterUsername(String username) {
        log.info("Entering username: {}", username);
        type(usernameInput, username);
        return this;
    }

    public LoginPage enterPassword(String password) {
        log.info("Entering password");
        type(passwordInput, password);
        return this;
    }

    public DashboardPage clickLogin() {
        log.info("Clicking login button");
        click(loginButton);
        return new DashboardPage(driver);
    }

    public LoginPage clickLoginExpectingFailure() {
        log.info("Clicking login button (expecting failure)");
        click(loginButton);
        return this;
    }

    /** Convenience method: full login flow → returns DashboardPage */
    public DashboardPage loginAs(String username, String password) {
        return enterUsername(username)
                .enterPassword(password)
                .clickLogin();
    }

    public LoginPage loginWithInvalidCreds(String username, String password) {
        return enterUsername(username)
                .enterPassword(password)
                .clickLoginExpectingFailure();
    }

    public void clickForgotPassword() {
        click(forgotPasswordLink);
    }

    // ─── Assertions / State ──────────────────────────────────────────────────────

    public boolean isSuccessMessageDisplayed() {
        return isDisplayed(org.openqa.selenium.By.cssSelector(".flash.success"));
    }

    public boolean isErrorMessageDisplayed() {
        return isDisplayed(org.openqa.selenium.By.cssSelector(".flash.error"));
    }

    public String getSuccessMessage() {
        return getText(successMessage);
    }

    public String getErrorMessage() {
        return getText(errorMessage);
    }

    public boolean isOnLoginPage() {
        return getCurrentUrl().contains("/login");
    }

    public boolean isLoginButtonEnabled() {
        return loginButton.isEnabled();
    }
}
