package com.automation.pages;

import com.automation.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for form-based interactions.
 * Targets form elements including text fields, dropdowns, checkboxes, file uploads, etc.
 */
public class FormPage extends BasePage {

    @FindBy(id = "first-name")
    private WebElement firstNameInput;

    @FindBy(id = "last-name")
    private WebElement lastNameInput;

    @FindBy(id = "email")
    private WebElement emailInput;

    @FindBy(id = "phone")
    private WebElement phoneInput;

    @FindBy(id = "country")
    private WebElement countryDropdown;

    @FindBy(id = "gender-male")
    private WebElement genderMaleRadio;

    @FindBy(id = "gender-female")
    private WebElement genderFemaleRadio;

    @FindBy(id = "terms-checkbox")
    private WebElement termsCheckbox;

    @FindBy(id = "comments")
    private WebElement commentsTextarea;

    @FindBy(css = "button[type='submit']")
    private WebElement submitButton;

    @FindBy(css = ".success-msg")
    private WebElement successMessage;

    @FindBy(css = ".error-msg")
    private WebElement errorMessage;

    @FindBy(css = ".field-error")
    private WebElement fieldError;

    public FormPage(WebDriver driver) {
        super(driver);
    }

    public FormPage open() {
        navigateTo(config.getBaseUrl() + "/form");
        log.info("Opened Form page");
        return this;
    }

    // ─── Field setters (fluent) ───────────────────────────────────────────────────

    public FormPage enterFirstName(String name) {
        type(firstNameInput, name);
        return this;
    }

    public FormPage enterLastName(String name) {
        type(lastNameInput, name);
        return this;
    }

    public FormPage enterEmail(String email) {
        type(emailInput, email);
        return this;
    }

    public FormPage enterPhone(String phone) {
        type(phoneInput, phone);
        return this;
    }

    public FormPage selectCountry(String country) {
        selectByVisibleText(By.id("country"), country);
        return this;
    }

    public FormPage selectGender(String gender) {
        if ("male".equalsIgnoreCase(gender)) {
            click(genderMaleRadio);
        } else {
            click(genderFemaleRadio);
        }
        return this;
    }

    public FormPage acceptTerms() {
        checkCheckbox(By.id("terms-checkbox"));
        return this;
    }

    public FormPage enterComments(String comments) {
        type(commentsTextarea, comments);
        return this;
    }

    public FormPage submit() {
        log.info("Submitting form");
        click(submitButton);
        return this;
    }

    // ─── Compound method ─────────────────────────────────────────────────────────

    public FormPage fillAndSubmit(String firstName, String lastName,
                                   String email, String phone,
                                   String country, String gender, String comments) {
        return enterFirstName(firstName)
                .enterLastName(lastName)
                .enterEmail(email)
                .enterPhone(phone)
                .selectCountry(country)
                .selectGender(gender)
                .acceptTerms()
                .enterComments(comments)
                .submit();
    }

    // ─── Assertions ──────────────────────────────────────────────────────────────

    public boolean isSuccessMessageDisplayed() {
        return isDisplayed(By.cssSelector(".success-msg"));
    }

    public boolean isErrorMessageDisplayed() {
        return isDisplayed(By.cssSelector(".error-msg"));
    }

    public String getSuccessMessage() {
        return getText(successMessage);
    }

    public String getErrorMessage() {
        return getText(errorMessage);
    }

    public String getFieldError() {
        return getText(fieldError);
    }

    public String getEmailFieldValue() {
        return getAttribute(By.id("email"), "value");
    }

    public boolean isSubmitEnabled() {
        return submitButton.isEnabled();
    }
}
