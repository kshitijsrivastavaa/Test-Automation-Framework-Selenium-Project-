package com.automation.pages;

import com.automation.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Page Object for the Dashboard / Home page (after login).
 */
public class DashboardPage extends BasePage {

    @FindBy(css = ".flash.success")
    private WebElement loginSuccessBanner;

    @FindBy(linkText = "Logout")
    private WebElement logoutLink;

    @FindBy(css = "#content h2")
    private WebElement pageHeading;

    @FindBy(css = "#content ul li a")
    private List<WebElement> navLinks;

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    // ─── Actions ─────────────────────────────────────────────────────────────────

    public LoginPage logout() {
        log.info("Logging out");
        click(logoutLink);
        return new LoginPage(driver);
    }

    public FormPage navigateToForm() {
        navigateTo(config.getBaseUrl() + "/login"); // adjust path as needed
        return new FormPage(driver);
    }

    // ─── Assertions ──────────────────────────────────────────────────────────────

    public boolean isLoggedIn() {
        return isDisplayed(By.linkText("Logout"));
    }

    public boolean isLoginBannerDisplayed() {
        return isDisplayed(By.cssSelector(".flash.success"));
    }

    public String getLoginBannerText() {
        return getText(loginSuccessBanner);
    }

    public String getPageHeading() {
        return getText(pageHeading);
    }

    public List<String> getNavLinkTexts() {
        return navLinks.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    public boolean isDashboardUrlCorrect() {
        return getCurrentUrl().contains("/secure");
    }
}
