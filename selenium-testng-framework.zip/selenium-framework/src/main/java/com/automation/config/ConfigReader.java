package com.automation.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton ConfigReader to load and provide config properties.
 * Supports environment-specific configs: config.properties, config-staging.properties, etc.
 */
public class ConfigReader {

    private static final Logger log = LogManager.getLogger(ConfigReader.class);
    private static ConfigReader instance;
    private final Properties properties;

    private ConfigReader() {
        properties = new Properties();
        String env = System.getProperty("env", "dev");
        loadProperties("src/test/resources/config.properties");
        loadProperties("src/test/resources/config-" + env + ".properties");
        log.info("ConfigReader initialized for env: {}", env);
    }

    public static ConfigReader getInstance() {
        if (instance == null) {
            synchronized (ConfigReader.class) {
                if (instance == null) instance = new ConfigReader();
            }
        }
        return instance;
    }

    private void loadProperties(String filePath) {
        try (InputStream is = new FileInputStream(filePath)) {
            properties.load(is);
            log.debug("Loaded config: {}", filePath);
        } catch (IOException e) {
            log.warn("Could not load config file: {} - {}", filePath, e.getMessage());
        }
    }

    public String get(String key) {
        String value = System.getProperty(key, properties.getProperty(key));
        if (value == null) {
            log.error("Config key not found: {}", key);
            throw new RuntimeException("Missing config key: " + key);
        }
        return value.trim();
    }

    public String get(String key, String defaultValue) {
        return System.getProperty(key, properties.getProperty(key, defaultValue)).trim();
    }

    public int getInt(String key) {
        return Integer.parseInt(get(key));
    }

    public boolean getBoolean(String key) {
        return Boolean.parseBoolean(get(key));
    }

    // Convenience getters
    public String getBaseUrl()          { return get("base.url"); }
    public String getBrowser()          { return get("browser", "chrome"); }
    public boolean isHeadless()         { return Boolean.parseBoolean(get("headless", "false")); }
    public int getImplicitWait()        { return getInt("implicit.wait"); }
    public int getExplicitWait()        { return getInt("explicit.wait"); }
    public int getPageLoadTimeout()     { return getInt("page.load.timeout"); }
    public String getUsername()         { return get("app.username"); }
    public String getPassword()         { return get("app.password"); }
    public String getScreenshotDir()    { return get("screenshot.dir", "reports/screenshots"); }
    public String getReportDir()        { return get("report.dir", "reports"); }
}
