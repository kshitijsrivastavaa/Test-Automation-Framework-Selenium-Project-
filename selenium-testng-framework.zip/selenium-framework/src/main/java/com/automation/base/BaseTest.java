package com.automation.base;

import com.automation.config.ConfigReader;
import com.automation.utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;

/**
 * BaseTest sets up/tears down WebDriver and wires ExtentReports for every test.
 * All test classes must extend this.
 */
public class BaseTest {

    protected static final Logger log = LogManager.getLogger(BaseTest.class);
    protected WebDriver driver;
    protected ConfigReader config;

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() {
        ExtentReportManager.initReports();
        createDirectories();
        log.info("===== Test Suite Started =====");
    }

    @BeforeMethod(alwaysRun = true)
    public void setUp(java.lang.reflect.Method method) {
        config = ConfigReader.getInstance();
        DriverManager.initDriver();
        driver = DriverManager.getDriver();

        // Open base URL
        driver.get(config.getBaseUrl());

        // Create ExtentTest node for this method
        ExtentTest test = ExtentReportManager.createTest(method.getName(),
                method.isAnnotationPresent(Test.class)
                        ? method.getAnnotation(Test.class).description()
                        : "");
        ExtentReportManager.setTest(test);

        log.info("----- Starting test: {} -----", method.getName());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        ExtentTest test = ExtentReportManager.getTest();

        if (result.getStatus() == ITestResult.FAILURE) {
            String screenshotPath = takeScreenshot(result.getName());
            log.error("TEST FAILED: {}", result.getName(), result.getThrowable());
            if (test != null) {
                test.fail(result.getThrowable());
                if (screenshotPath != null) {
                    test.addScreenCaptureFromPath(screenshotPath, "Failure Screenshot");
                }
            }
        } else if (result.getStatus() == ITestResult.SKIP) {
            log.warn("TEST SKIPPED: {}", result.getName());
            if (test != null) test.skip(result.getThrowable());
        } else {
            log.info("TEST PASSED: {}", result.getName());
            if (test != null) test.pass("Test passed");
        }

        DriverManager.quitDriver();
        log.info("----- Finished test: {} -----", result.getName());
    }

    @AfterSuite(alwaysRun = true)
    public void afterSuite() {
        ExtentReportManager.flushReports();
        log.info("===== Test Suite Completed =====");
    }

    private String takeScreenshot(String testName) {
        try {
            return com.automation.utils.ScreenshotUtil.capture(driver, testName);
        } catch (Exception e) {
            log.warn("Could not capture screenshot: {}", e.getMessage());
            return null;
        }
    }

    private void createDirectories() {
        String[] dirs = {"reports", "reports/screenshots"};
        for (String dir : dirs) {
            new File(dir).mkdirs();
        }
    }

    // Allow tests to log steps to report
    protected void logStep(String message) {
        log.info(message);
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) test.log(Status.INFO, message);
    }

    protected void logPass(String message) {
        log.info(message);
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) test.pass(message);
    }

    protected void logFail(String message) {
        log.error(message);
        ExtentTest test = ExtentReportManager.getTest();
        if (test != null) test.fail(message);
    }
}
