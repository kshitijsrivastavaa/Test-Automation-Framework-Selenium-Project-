package com.automation.base;

import com.automation.config.ConfigReader;
import com.automation.utils.ScreenshotUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * BasePage provides reusable Selenium actions for all Page Object classes.
 */
public class BasePage {

    protected static final Logger log = LogManager.getLogger(BasePage.class);
    protected WebDriver driver;
    protected WebDriverWait wait;
    protected Actions actions;
    protected ConfigReader config;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.config = ConfigReader.getInstance();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(config.getExplicitWait()));
        this.actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }

    // ─── Navigation ─────────────────────────────────────────────────────────────

    public void navigateTo(String url) {
        log.info("Navigating to: {}", url);
        driver.get(url);
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public String getTitle() {
        return driver.getTitle();
    }

    // ─── Wait Helpers ────────────────────────────────────────────────────────────

    public WebElement waitForVisible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public WebElement waitForClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public WebElement waitForClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public boolean waitForInvisible(By locator) {
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    public void waitForUrl(String urlFragment) {
        wait.until(ExpectedConditions.urlContains(urlFragment));
    }

    public void waitForText(By locator, String text) {
        wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
    }

    // ─── Element Actions ─────────────────────────────────────────────────────────

    public void click(By locator) {
        log.debug("Clicking: {}", locator);
        waitForClickable(locator).click();
    }

    public void click(WebElement element) {
        log.debug("Clicking element: {}", element);
        waitForClickable(element).click();
    }

    public void type(By locator, String text) {
        log.debug("Typing '{}' into: {}", text, locator);
        WebElement element = waitForVisible(locator);
        element.clear();
        element.sendKeys(text);
    }

    public void type(WebElement element, String text) {
        log.debug("Typing '{}' into element", text);
        waitForClickable(element);
        element.clear();
        element.sendKeys(text);
    }

    public String getText(By locator) {
        return waitForVisible(locator).getText().trim();
    }

    public String getText(WebElement element) {
        return element.getText().trim();
    }

    public String getAttribute(By locator, String attribute) {
        return waitForVisible(locator).getAttribute(attribute);
    }

    public boolean isDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public boolean isEnabled(By locator) {
        return driver.findElement(locator).isEnabled();
    }

    public List<WebElement> findAll(By locator) {
        return driver.findElements(locator);
    }

    // ─── Dropdown ────────────────────────────────────────────────────────────────

    public void selectByVisibleText(By locator, String text) {
        log.debug("Selecting '{}' by visible text", text);
        new Select(waitForVisible(locator)).selectByVisibleText(text);
    }

    public void selectByValue(By locator, String value) {
        new Select(waitForVisible(locator)).selectByValue(value);
    }

    public void selectByIndex(By locator, int index) {
        new Select(waitForVisible(locator)).selectByIndex(index);
    }

    // ─── Checkbox / Radio ────────────────────────────────────────────────────────

    public void checkCheckbox(By locator) {
        WebElement cb = driver.findElement(locator);
        if (!cb.isSelected()) cb.click();
    }

    public void uncheckCheckbox(By locator) {
        WebElement cb = driver.findElement(locator);
        if (cb.isSelected()) cb.click();
    }

    // ─── JS Executor ─────────────────────────────────────────────────────────────

    public void jsClick(WebElement element) {
        log.debug("JS click on element");
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    public void jsScrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public void jsScrollToBottom() {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
    }

    public Object executeJS(String script, Object... args) {
        return ((JavascriptExecutor) driver).executeScript(script, args);
    }

    // ─── Hover / Drag ────────────────────────────────────────────────────────────

    public void hover(WebElement element) {
        actions.moveToElement(element).perform();
    }

    public void dragAndDrop(WebElement source, WebElement target) {
        actions.dragAndDrop(source, target).perform();
    }

    // ─── Alerts ──────────────────────────────────────────────────────────────────

    public String getAlertText() {
        return wait.until(ExpectedConditions.alertIsPresent()).getText();
    }

    public void acceptAlert() {
        wait.until(ExpectedConditions.alertIsPresent()).accept();
    }

    public void dismissAlert() {
        wait.until(ExpectedConditions.alertIsPresent()).dismiss();
    }

    // ─── Frames ──────────────────────────────────────────────────────────────────

    public void switchToFrame(String nameOrId) {
        driver.switchTo().frame(nameOrId);
    }

    public void switchToDefaultContent() {
        driver.switchTo().defaultContent();
    }

    // ─── Screenshot ──────────────────────────────────────────────────────────────

    public String takeScreenshot(String name) {
        return ScreenshotUtil.capture(driver, name);
    }

    // ─── Waits ───────────────────────────────────────────────────────────────────

    public void hardWait(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
